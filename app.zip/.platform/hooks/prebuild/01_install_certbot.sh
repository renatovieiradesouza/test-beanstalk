#!/usr/bin/env bash
# instalar EPEL e certbot + plugin nginx
yum install -y epel-release
yum install -y certbot python3-certbot-nginx
